package edu.fatec.lp2.figuras;

public interface Calculable {
	double calcularArea();
}
